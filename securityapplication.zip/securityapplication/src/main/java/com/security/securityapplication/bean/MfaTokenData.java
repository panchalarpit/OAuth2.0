package com.security.securityapplication.bean;
import java.io.Serializable;

public class MfaTokenData implements Serializable {
  private final String qrCode;
  private final String mfaCode;

  public MfaTokenData(String qrCode, String mfaCode) {
    this.qrCode = qrCode;
    this.mfaCode = mfaCode;
  }

  public String getQrCode() {
    return qrCode;
  }
  public String getMfaCode() {
    return mfaCode;
  }
}
