package com.security.securityapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityApplicationApplication {
	public static void main(String[] args) {
		SpringApplication.run(SecurityApplicationApplication.class, args);
	}
}