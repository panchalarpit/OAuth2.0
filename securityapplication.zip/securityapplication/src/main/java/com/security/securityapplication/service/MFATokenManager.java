package com.security.securityapplication.service;

import com.google.zxing.WriterException;
import dev.samstevens.totp.exceptions.QrGenerationException;
import java.io.IOException;

public interface MFATokenManager {
  String generateSecretKey();
  String generateQRCode(String secret) throws QrGenerationException, WriterException, IOException;
  Boolean verifyTotp(String code, String secret);
}
