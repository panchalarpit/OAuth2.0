package com.security.securityapplication.service;

import com.google.zxing.WriterException;
import com.security.securityapplication.bean.MfaTokenData;
import com.security.securityapplication.bean.User;
import com.security.securityapplication.bean.UserDetailsPrincipal;
import com.security.securityapplication.dao.UserDetailsDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import java.io.IOException;
import java.util.List;

@Service
public class UserServiceImpl implements UserService {
  @Autowired
  UserDetailsDao userDetailsDao;
  @Autowired
  DefaultMFATokenManager mfaTokenManager;
  @Override
  public List<User> allUserDetails() {
    return userDetailsDao.findAll();
  }

  @Override
  public User userDetails(String username) {
    User user=new User();
    if(userDetailsDao.findByUsername(username)==null)
    {
      return user;
    }
    return userDetailsDao.findByUsername(username);
  }

  @Override
  public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
    User user=userDetailsDao.findByUsername(username);
    if(user == null)
      throw new UsernameNotFoundException("User not found");
    return new UserDetailsPrincipal(user);
  }

  @Override
  public void addUser(User user) {
    userDetailsDao.save(user);
  }

  @Override
  public int updateUserByUsername(String name, String email, String username) {
    return userDetailsDao.updateUserByUsername(name, email, username);
  }

  @Override
  public int updatePasswordByUsername(String name, String email, String username, String password) {
    return userDetailsDao.updatePasswordByUsername(name, email, username, password);
  }

  @Override
  public MfaTokenData mfaSetup(String username, String secret) throws UsernameNotFoundException, IOException, WriterException {
    return new MfaTokenData(mfaTokenManager.generateQRCode(secret),secret);
  }
}
