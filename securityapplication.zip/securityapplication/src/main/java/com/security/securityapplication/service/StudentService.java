package com.security.securityapplication.service;

import com.security.securityapplication.bean.Student;
import java.util.List;

public interface StudentService {
  List<Student> findAllStudent();
  Student findStudentById(int id);
}
