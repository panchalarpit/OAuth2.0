package com.security.securityapplication.dao;

import com.security.securityapplication.bean.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface StudentDetailDao extends JpaRepository<Student, Integer> {
  @Query(value = "SELECT * FROM student s WHERE s.student_id= :id", nativeQuery = true)
  Student findStudentById(@Param("id") int id);
}
