package com.security.securityapplication.bean;

import javax.persistence.*;

@Entity
@Table(name = "student")
public class Student {
  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  @Column(name = "student_id")
  private int studentId;
  @Column(name = "student_address")
  private String studentAddress;
  @Column(name = "student_name")
  private String studentName;

  public int getStudentId() {
    return studentId;
  }

  public void setStudentId(int studentId) {
    this.studentId = studentId;
  }

  public String getStudentAddress() {
    return studentAddress;
  }

  public void setStudentAddress(String studentAddress) {
    this.studentAddress = studentAddress;
  }

  public String getStudentName() {
    return studentName;
  }

  public void setStudentName(String studentName) {
    this.studentName = studentName;
  }
}
