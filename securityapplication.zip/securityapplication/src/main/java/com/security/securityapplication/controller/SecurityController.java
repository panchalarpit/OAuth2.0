package com.security.securityapplication.controller;

import com.google.zxing.WriterException;
import com.security.securityapplication.bean.MfaTokenData;
import com.security.securityapplication.bean.User;
import com.security.securityapplication.service.DefaultMFATokenManager;
import com.security.securityapplication.service.UserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import java.io.IOException;
import java.util.List;

@Controller
public class SecurityController {
  @Autowired
  UserServiceImpl userDetailsService;
  @Autowired
  HttpSession httpSession;
  @Autowired
  DefaultMFATokenManager mfaTokenManager;

  @RequestMapping("/loginpage")
  public ModelAndView login()
  {
    ModelAndView mv=new ModelAndView();
    mv.setViewName("login");
    return mv;
  }

  @RequestMapping("/register")
  public ModelAndView registration(){
    ModelAndView mv=new ModelAndView();
    User user=new User();
    mv.addObject("user",user);
    mv.setViewName("register");
    return mv;
  }

  @PostMapping(value = "/register/addNewUser")
  public ModelAndView addNewUser(@RequestParam("name")String name, @RequestParam("email")String email,
                                 @RequestParam("username")String username, @RequestParam("password")String password,
                                 @RequestParam("otp")String otp, @RequestParam("secret")String secret,
                                 @RequestParam("qrCode")String qrCode, @RequestParam("mfaCode")String mfaCode){
    ModelAndView mv=new ModelAndView();
    User user=new User();
    user.setName(name);
    user.setEmail(email);
    user.setUsername(username);
    user.setPassword(password);
    user.setMfaEnable(true);
    user.setRole("USER");
    user.setSecret(secret);
    if(mfaTokenManager.verifyTotp(otp,secret)){
      mv.addObject("user",user);
      userDetailsService.addUser(user);
      mv.setViewName("login");
    }
    else {
      mv.addObject("user",user);
      mv.addObject("qrCode",qrCode);
      mv.addObject("mfaCode",mfaCode);
      mv.addObject("error","Please enter correct OTP");
      mv.setViewName("register");
    }
    return mv;
  }

  @PostMapping(value = "/register/addUser")
  public ModelAndView addUser(@ModelAttribute("user") @Valid User user) throws IOException, WriterException {
    User userCheck=userDetailsService.userDetails(user.getUsername());
    ModelAndView mv;
    if(userCheck.getUserId()==0)
    {
      mv = new ModelAndView();
      String password=user.getPassword();
      BCryptPasswordEncoder bCryptPasswordEncoder=new BCryptPasswordEncoder();
      password=bCryptPasswordEncoder.encode(password);
      user.setPassword(password);
      user.setMfaEnable(true);
      user.setSecret(mfaTokenManager.generateSecretKey());
//      userDetailsService.addUser(user);
      mv.addObject("user",user);
      MfaTokenData mfaTokenData=userDetailsService.mfaSetup(user.getUsername(),user.getSecret());
      mv.addObject("qrCode",mfaTokenData.getQrCode());
      mv.addObject("mfaCode",mfaTokenData.getMfaCode());
      mv.setViewName("register");
    }else{
      mv = new ModelAndView();
      mv.addObject("error",user.getUsername()+" is already taken");
      mv.setViewName("register");
    }
    return mv;
  }

  @RequestMapping("/")
  public ModelAndView index()
  {
    ModelAndView mv=new ModelAndView();
    mv.setViewName("index");
    List<User> users=userDetailsService.allUserDetails();
    mv.addObject("user",users);
    return mv;
  }

  @RequestMapping("/profile")
  public ModelAndView profile(){
    ModelAndView mv=new ModelAndView();
    String username= (String) httpSession.getAttribute("username");
    User user=userDetailsService.userDetails(username);
    mv.addObject("user",user);
    mv.setViewName("profile");
    return mv;
  }

  @RequestMapping(value = "/updateUser")
  public ModelAndView updateUser(@RequestParam("name")String name,@RequestParam("username")String username,
                                 @RequestParam("password")String password,@RequestParam("newPassword")String newPassword,
                                 @RequestParam("email")String email){
    ModelAndView mv=new ModelAndView();
    User user=userDetailsService.userDetails(username);
    if(user.getPassword()==null && newPassword!= "" ){
      mv.addObject("error","You cannot update your password");
    } else if (user.getPassword()!=password && user.getPassword()!=null && password!="") {
      mv.addObject("error", "Please Enter correct password");
    } else if(password !="" && newPassword=="") {
      mv.addObject("error","please enter new password");
    }else if(password==""){
      if(userDetailsService.updateUserByUsername(name,email,username)==0){
        mv.addObject("error","Data not Updated"); }
      else{
        mv.addObject("msg","Data Updated");}
    } else if (user.getPassword().equals(password) && user.getPassword()!=null && password!="") {
      if (userDetailsService.updatePasswordByUsername(name, email, username, password) == 0) {
        mv.addObject("error", "Password not Updated");
      } else {
        mv.addObject("msg", "Password updated");
      }
    }
    User newUser=userDetailsService.userDetails(username);
    mv.addObject("user",newUser);
    mv.setViewName("profile");
    return mv;
  }

  @RequestMapping("/userList")
  public ModelAndView userList(){
    ModelAndView mv=new ModelAndView();
    List<User> users=userDetailsService.allUserDetails();
    mv.setViewName("userList");
    mv.addObject("users",users);
    return mv;
  }
}