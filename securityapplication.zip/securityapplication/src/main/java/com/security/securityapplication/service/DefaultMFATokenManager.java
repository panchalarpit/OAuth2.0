package com.security.securityapplication.service;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import dev.samstevens.totp.util.Utils;
import dev.turingcomplete.kotlinonetimepassword.GoogleAuthenticator;
import org.springframework.stereotype.Component;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Date;

@Component
public class DefaultMFATokenManager implements MFATokenManager{
  @Override
  public String generateSecretKey() {
    return GoogleAuthenticator.Companion.createRandomSecret();
  }
  @Override
  public String generateQRCode(String secret) throws WriterException, IOException {
    String uri="otpauth://totp/admin:arpit.panchal@gmail.com?secret="+secret+"&issuer=admin";
    QRCodeWriter writer=new QRCodeWriter();
    BitMatrix matrix;
    matrix = writer.encode(uri, BarcodeFormat.QR_CODE,200,200);
    ByteArrayOutputStream pngOutputStream = new ByteArrayOutputStream();
    MatrixToImageWriter.writeToStream(matrix, "PNG", pngOutputStream);
    return Utils.getDataUriForImage(pngOutputStream.toByteArray(),"image/png");
  }
  @Override
  public Boolean verifyTotp(String code, String secret) {
    Date timestamp= new Date(System.currentTimeMillis());
    String compareCode = new GoogleAuthenticator(secret).generate(timestamp);
    return compareCode.equals(code);
  }
}
