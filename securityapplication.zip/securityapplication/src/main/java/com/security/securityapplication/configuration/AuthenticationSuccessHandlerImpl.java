package com.security.securityapplication.configuration;

import com.security.securityapplication.bean.User;
import com.security.securityapplication.service.UserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Map;

@Component
public class AuthenticationSuccessHandlerImpl implements AuthenticationSuccessHandler {
  @Autowired
  HttpSession session;
  @Autowired
  UserServiceImpl userService;

  @Override
  public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws IOException {
    String username =  null;
    String role = null;
    if(authentication instanceof OAuth2AuthenticationToken)
    {
      OAuth2AuthenticationToken auth2AuthenticationToken= (OAuth2AuthenticationToken) authentication;
      username=auth2AuthenticationToken.getPrincipal().getName();
      Map<String,Object> mapAuth=auth2AuthenticationToken.getPrincipal().getAttributes();
      if(userService.userDetails(username).getUsername()==null)
      {
        User userBean = new User();
        userBean.setEmail((String) mapAuth.get("email"));
        userBean.setName((String) mapAuth.get("name"));
        userBean.setUsername(username);
        userBean.setRole("USER");
        role="USER";
        userService.addUser(userBean);
      }
      else{
        role=userService.userDetails(username).getRole();
      }
    }
    else{
      username=authentication.getName();
      role=userService.userDetails(username).getRole();
      System.out.println(username + role);
    }
    session.setAttribute("username",username);
    session.setAttribute("role",role);
    response.sendRedirect("/");
  }
}
