package com.security.securityapplication.configuration;

import org.springframework.security.web.authentication.WebAuthenticationDetails;
import javax.servlet.http.HttpServletRequest;
import java.util.Objects;

public class CustomWebAuthenticationDetails extends WebAuthenticationDetails {
  private final String token;
  public CustomWebAuthenticationDetails(HttpServletRequest request) {
    super(request);
    this.token=request.getParameter("mfaToken");
  }

  @Override
  public String toString() {
    return "CustomWebAuthenticationDetails{" +
        "token='" + token + '\'' +
        '}';
  }

  @Override
  public int hashCode() {
    return Objects.hash(super.hashCode(),token);
  }

  @Override
  public boolean equals(Object obj) {
    if(this == obj) return true;
    if(obj ==null || getClass() != obj.getClass()) return false;
    if(!super.equals(obj)) return false;
    CustomWebAuthenticationDetails customWebAuthenticationDetails= (CustomWebAuthenticationDetails) obj;
    return Objects.equals(token, customWebAuthenticationDetails.token);
  }

  public String getToken() {
    return token;
  }
}
