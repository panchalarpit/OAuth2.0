package com.security.securityapplication.service;

import com.security.securityapplication.bean.Student;
import com.security.securityapplication.dao.StudentDetailDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class StudentServiceImpl implements StudentService{
  @Autowired
  StudentDetailDao studentDetails;

  @Override
  public List<Student> findAllStudent() {
    return studentDetails.findAll();
  }

  @Override
  public Student findStudentById(int id) {
    return studentDetails.findStudentById(id);
  }
}
