package com.security.securityapplication.exception;

public class StudentExceptionClass extends RuntimeException{
  String errorMessage;

  public StudentExceptionClass(String errorMessage ){
    this.errorMessage=errorMessage;
  }
}
