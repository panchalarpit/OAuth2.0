package com.security.securityapplication.service;

import com.google.zxing.WriterException;
import com.security.securityapplication.bean.MfaTokenData;
import com.security.securityapplication.bean.User;
import dev.samstevens.totp.exceptions.QrGenerationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import java.io.IOException;
import java.util.List;

public interface UserService extends UserDetailsService {
  List<User> allUserDetails();
  User userDetails(String username);
  UserDetails loadUserByUsername(String username) throws UsernameNotFoundException;
  void addUser(User user);
  int updateUserByUsername(String name, String email, String username);
  int updatePasswordByUsername(String name, String email, String username, String password);
  MfaTokenData mfaSetup(String username, String secret) throws UsernameNotFoundException, QrGenerationException, IOException, WriterException;
}
