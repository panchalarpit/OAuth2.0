package com.security.securityapplication.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class SecurityAPIController {

  @RequestMapping("/index")
  public String index(){
    return "index ";
  }

  @ExceptionHandler
  public String errorHandler(){
    return "Page not found";
  }
}
