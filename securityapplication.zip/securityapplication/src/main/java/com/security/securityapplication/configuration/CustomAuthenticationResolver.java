package com.security.securityapplication.configuration;

import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
import org.springframework.security.oauth2.client.web.DefaultOAuth2AuthorizationRequestResolver;
import org.springframework.security.oauth2.client.web.OAuth2AuthorizationRequestResolver;
import org.springframework.security.oauth2.core.endpoint.OAuth2AuthorizationRequest;
import org.springframework.stereotype.Component;
import javax.servlet.http.HttpServletRequest;
import java.util.LinkedHashMap;
import java.util.Map;

@Component
public class CustomAuthenticationResolver implements OAuth2AuthorizationRequestResolver {

  private final OAuth2AuthorizationRequestResolver oAuth2AuthorizationRequestResolver;

  public CustomAuthenticationResolver(ClientRegistrationRepository clientRegistrationRepository) {
    this.oAuth2AuthorizationRequestResolver = new DefaultOAuth2AuthorizationRequestResolver(clientRegistrationRepository,
        "/oauth2/authorization");
  }

  @Override
  public OAuth2AuthorizationRequest resolve(HttpServletRequest request) {
    OAuth2AuthorizationRequest authorizationRequest=this.oAuth2AuthorizationRequestResolver.resolve(request);
    return authorizationRequest != null ? customAuthorizationRequest(authorizationRequest) : null;
  }

  @Override
  public OAuth2AuthorizationRequest resolve(HttpServletRequest request, String clientRegistrationId) {
    OAuth2AuthorizationRequest authorizationRequest=this.oAuth2AuthorizationRequestResolver.resolve(request
        , clientRegistrationId);
    return authorizationRequest !=null ?customAuthorizationRequest(authorizationRequest) : null;
  }

  private OAuth2AuthorizationRequest customAuthorizationRequest(OAuth2AuthorizationRequest authorizationRequest){
    Map<String, Object> additionalObject= new LinkedHashMap<>(authorizationRequest.getAdditionalParameters());
    additionalObject.put("prompt","login");
    return  OAuth2AuthorizationRequest.from(authorizationRequest).additionalParameters(additionalObject).build();
  }
}
