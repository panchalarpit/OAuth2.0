package com.security.securityapplication.configuration;

import com.security.securityapplication.bean.UserDetailsPrincipal;
import com.security.securityapplication.service.DefaultMFATokenManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class CustomAuthenticationProvider extends DaoAuthenticationProvider {
  @Autowired
  private DefaultMFATokenManager mfaTokenManager;

  @Autowired
  public CustomAuthenticationProvider(UserDetailsService userDetailsService){
    super.setUserDetailsService(userDetailsService);
    super.setPasswordEncoder(new BCryptPasswordEncoder());
  }

  protected void additionalAuthenticationChecks (UserDetails userDetails, UsernamePasswordAuthenticationToken authentication)
      throws AuthenticationException {
    super.additionalAuthenticationChecks(userDetails,authentication);
    CustomWebAuthenticationDetails authenticationDetails= (CustomWebAuthenticationDetails) authentication.getDetails();
    UserDetailsPrincipal user= (UserDetailsPrincipal) userDetails;
    String token=authenticationDetails.getToken();
    if(!mfaTokenManager.verifyTotp(token,user.getSecret())){
      throw new BadCredentialsException(messages.getMessage("AbstractUserDetailsAuthenticationProvider.badCredentials"
          ,"Wrong Credentials"));
    }
  }
}
