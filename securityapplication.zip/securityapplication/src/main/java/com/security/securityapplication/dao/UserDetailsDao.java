package com.security.securityapplication.dao;

import com.security.securityapplication.bean.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface UserDetailsDao extends JpaRepository<User, Integer> {
  User findByUsername(String username);
  @Modifying
  @Transactional
  @Query("update User u set u.name=:#{#name}, u.email=:#{#email} where u.username=:#{#username}")
  int updateUserByUsername(@Param("name") String name,@Param("email") String email,@Param("username") String username);

  @Modifying
  @Transactional
  @Query("update User u set u.name=:#{#name}, u.email=:#{#email}, u.password=:#{#password} where u.username=:#{#username}")
  int updatePasswordByUsername(@Param("name") String name,@Param("email") String email,@Param("username") String username,@Param("password") String password);
}
