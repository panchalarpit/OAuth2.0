package com.security.securityapplication.configuration;

import com.security.securityapplication.service.UserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.oauth2.client.oidc.web.logout.OidcClientInitiatedLogoutSuccessHandler;
import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@Configuration
@EnableWebSecurity
public class SecurityApplicationConfig extends WebSecurityConfigurerAdapter {
  @Autowired
  private AuthenticationSuccessHandlerImpl authenticationSuccessHandler;
  @Autowired
  private UserServiceImpl userDetailsService;
  @Autowired
  private ClientRegistrationRepository clientRegistrationRepository;
  @Autowired
  private CustomWebAuthenticationDetailsSource authenticationDetailsSource;

  @Override
  protected void configure(HttpSecurity http) throws Exception {
    String loginUrl="/loginpage";
    http
        .csrf().disable()
        .antMatcher("/**")
        .authorizeRequests().antMatchers("/register/**","/register").permitAll()
        .anyRequest().authenticated()
        .and().formLogin().loginPage(loginUrl).permitAll().loginProcessingUrl("/login")
        .successHandler(authenticationSuccessHandler)
        .authenticationDetailsSource(authenticationDetailsSource)
        .and().logout().invalidateHttpSession(true).clearAuthentication(true)
        .logoutSuccessHandler(oidcClientInitiatedLogoutSuccessHandler())
        .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
        .logoutSuccessUrl(loginUrl).permitAll()
        .and().oauth2Login().loginPage(loginUrl).successHandler(authenticationSuccessHandler).authorizationEndpoint()
        .authorizationRequestResolver(new CustomAuthenticationResolver(clientRegistrationRepository));
  }

  public OidcClientInitiatedLogoutSuccessHandler oidcClientInitiatedLogoutSuccessHandler()
  {
    OidcClientInitiatedLogoutSuccessHandler successHandler=new
        OidcClientInitiatedLogoutSuccessHandler(clientRegistrationRepository);
    successHandler.setPostLogoutRedirectUri("http://localhost:9090/");
    return successHandler;
  }

  @Bean
  public AuthenticationProvider authenticationProvider(){
    return new CustomAuthenticationProvider(userDetailsService);
  }
}
